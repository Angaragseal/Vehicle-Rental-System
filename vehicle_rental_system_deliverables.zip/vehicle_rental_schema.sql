
-- ===========================================
-- Vehicle Rental System - MySQL Database Setup
-- ===========================================

-- Drop tables if they already exist (for fresh setup)
DROP TABLE IF EXISTS payment, booking, damage_report, vehicle, vehicle_type, customer, pricing, branch;

-- ========================
-- 1. Branch Table
-- Stores branch locations of the rental service
-- ========================
CREATE TABLE branch (
    branch_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    location VARCHAR(100)
);

-- ========================
-- 2. Vehicle Type Table
-- Stores types of vehicles (Car, Bike, etc.)
-- ========================
CREATE TABLE vehicle_type (
    type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(50) UNIQUE NOT NULL
);

-- ========================
-- 3. Vehicle Table
-- Stores details about each vehicle
-- ========================
CREATE TABLE vehicle (
    vehicle_id INT AUTO_INCREMENT PRIMARY KEY,
    type_id INT,
    make VARCHAR(50),
    model VARCHAR(50),
    year YEAR,
    registration_number VARCHAR(20) UNIQUE NOT NULL,
    status ENUM('Available', 'Booked', 'Under Maintenance') DEFAULT 'Available',
    branch_id INT,
    FOREIGN KEY (type_id) REFERENCES vehicle_type(type_id),
    FOREIGN KEY (branch_id) REFERENCES branch(branch_id)
);

-- ========================
-- 4. Customer Table
-- Stores customer details and identification
-- ========================
CREATE TABLE customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15),
    id_proof VARCHAR(50)
);

-- ========================
-- 5. Booking Table
-- Stores vehicle bookings by customers
-- ========================
CREATE TABLE booking (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    vehicle_id INT,
    start_date DATE,
    end_date DATE,
    status ENUM('Active', 'Cancelled', 'Completed') DEFAULT 'Active',
    FOREIGN KEY (customer_id) REFERENCES customer(customer_id),
    FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id)
);

-- ========================
-- 6. Damage Report Table
-- Logs damage reports for vehicles
-- ========================
CREATE TABLE damage_report (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT,
    report_date DATE,
    damage_type VARCHAR(100),
    severity ENUM('Low', 'Medium', 'High'),
    resolution_status ENUM('Pending', 'Resolved'),
    FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id)
);

-- ========================
-- 7. Pricing Table
-- Stores pricing information for vehicle types
-- ========================
CREATE TABLE pricing (
    type_id INT PRIMARY KEY,
    daily_rate DECIMAL(10,2),
    hourly_rate DECIMAL(10,2),
    late_fee DECIMAL(10,2),
    FOREIGN KEY (type_id) REFERENCES vehicle_type(type_id)
);

-- ========================
-- 8. Payment Table
-- Stores payment details for bookings
-- ========================
CREATE TABLE payment (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT,
    amount DECIMAL(10,2),
    payment_status ENUM('Paid', 'Pending'),
    payment_method ENUM('Card', 'Cash', 'UPI'),
    payment_date DATE,
    FOREIGN KEY (booking_id) REFERENCES booking(booking_id)
);

-- ========================
-- Sample Data Insertion
-- Insert multiple records to test functionality
-- ========================

-- Branches
INSERT INTO branch (name, location) VALUES 
('Main Branch', 'Mumbai'),
('South Branch', 'Bangalore'),
('North Branch', 'Delhi'),
('East Branch', 'Kolkata'),
('West Branch', 'Pune');

-- Vehicle Types
INSERT INTO vehicle_type (type_name) VALUES 
('Car'), ('Bike'), ('Scooter'), ('Van'), ('SUV'), ('Truck');

-- Pricing for vehicle types
INSERT INTO pricing (type_id, daily_rate, hourly_rate, late_fee) VALUES 
(1, 1500.00, 200.00, 300.00),
(2, 500.00, 70.00, 100.00),
(3, 400.00, 60.00, 80.00),
(4, 1800.00, 250.00, 350.00),
(5, 2000.00, 270.00, 400.00),
(6, 2200.00, 300.00, 500.00);

-- Customers
INSERT INTO customer (name, email, phone, id_proof) VALUES 
('Alice Smith', 'alice@example.com', '9876543210', 'DL12345'),
('Ravi Kumar', 'ravi.kumar@example.com', '9988776655', 'DL54321'),
('Priya Desai', 'priya.desai@example.com', '8899776655', 'PAN12345'),
('John Doe', 'john.doe@example.com', '7777666655', 'AADHAR9876'),
('Neha Mehta', 'neha.mehta@example.com', '9999888877', 'DL67890');

-- Vehicles
INSERT INTO vehicle (type_id, make, model, year, registration_number, status, branch_id) VALUES 
(1, 'Toyota', 'Corolla', 2022, 'MH12AB1234', 'Available', 1),
(2, 'Honda', 'CBR 150R', 2021, 'MH12BC5678', 'Available', 1),
(5, 'Mahindra', 'Scorpio', 2023, 'KA05MK7890', 'Under Maintenance', 2),
(1, 'Hyundai', 'i20', 2023, 'DL01AB1234', 'Booked', 3),
(2, 'Yamaha', 'FZ', 2022, 'WB20YZ9876', 'Available', 4),
(3, 'TVS', 'Jupiter', 2021, 'MH14ZX4567', 'Booked', 2),
(4, 'Force', 'Traveller', 2020, 'DL04TR1234', 'Available', 1),
(6, 'Tata', '407', 2019, 'GJ10TR9988', 'Under Maintenance', 5);

-- Bookings
INSERT INTO booking (customer_id, vehicle_id, start_date, end_date, status) VALUES 
(1, 1, '2025-06-20', '2025-06-22', 'Active'),
(2, 4, '2025-06-18', '2025-06-20', 'Completed'),
(3, 2, '2025-06-21', '2025-06-23', 'Active'),
(4, 5, '2025-06-25', '2025-06-26', 'Cancelled'),
(1, 6, '2025-06-10', '2025-06-12', 'Completed'),
(2, 7, '2025-06-15', '2025-06-17', 'Active');

-- Payments
INSERT INTO payment (booking_id, amount, payment_status, payment_method, payment_date) VALUES 
(1, 3000.00, 'Paid', 'Card', '2025-06-18'),
(2, 1800.00, 'Paid', 'Cash', '2025-06-18'),
(3, 1200.00, 'Pending', 'UPI', '2025-06-21'),
(4, 0.00, 'Pending', 'Cash', NULL),
(5, 2500.00, 'Paid', 'Card', '2025-06-10'),
(6, 2200.00, 'Paid', 'UPI', '2025-06-15');

-- Damage Reports
INSERT INTO damage_report (vehicle_id, report_date, damage_type, severity, resolution_status) VALUES 
(3, '2025-06-10', 'Engine Failure', 'High', 'Pending'),
(5, '2025-06-12', 'Scratches on door', 'Low', 'Resolved'),
(6, '2025-06-16', 'Broken headlight', 'Medium', 'Pending'),
(7, '2025-06-17', 'Clutch issues', 'High', 'Resolved');

-- =========================
-- Sample Queries to Demonstrate Functionality
-- =========================

-- 1. Booking with Vehicle and Customer Info
SELECT 
    b.booking_id,
    c.name AS customer_name,
    v.make AS vehicle_make,
    v.model AS vehicle_model,
    vt.type_name AS vehicle_type,
    b.start_date,
    b.end_date,
    b.status
FROM booking b
JOIN customer c ON b.customer_id = c.customer_id
JOIN vehicle v ON b.vehicle_id = v.vehicle_id
JOIN vehicle_type vt ON v.type_id = vt.type_id;

-- 2. Vehicles with Branch and Type Info
SELECT 
    v.vehicle_id,
    v.make,
    v.model,
    vt.type_name AS vehicle_type,
    br.name AS branch_name,
    br.location,
    v.status
FROM vehicle v
JOIN vehicle_type vt ON v.type_id = vt.type_id
JOIN branch br ON v.branch_id = br.branch_id;

-- 3. Damage Reports with Vehicle and Branch Info
SELECT 
    dr.report_id,
    v.registration_number,
    v.make,
    v.model,
    br.name AS branch,
    dr.damage_type,
    dr.severity,
    dr.resolution_status,
    dr.report_date
FROM damage_report dr
JOIN vehicle v ON dr.vehicle_id = v.vehicle_id
JOIN branch br ON v.branch_id = br.branch_id;

-- 4. Payments with Customer and Booking Info
SELECT 
    p.payment_id,
    c.name AS customer,
    p.amount,
    p.payment_method,
    p.payment_status,
    p.payment_date
FROM payment p
JOIN booking b ON p.booking_id = b.booking_id
JOIN customer c ON b.customer_id = c.customer_id;

-- 5. Bookings Where Vehicle is Under Maintenance
SELECT 
    b.booking_id,
    c.name AS customer,
    v.make,
    v.model,
    v.status
FROM booking b
JOIN vehicle v ON b.vehicle_id = v.vehicle_id
JOIN customer c ON b.customer_id = c.customer_id
WHERE v.status = 'Under Maintenance';
